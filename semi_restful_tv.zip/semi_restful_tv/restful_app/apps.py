from django.apps import AppConfig


class RestfulAppConfig(AppConfig):
    name = 'restful_app'
